using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Threading.Tasks;
using PlayClientApp.Adapters;
using PlayClientApp.Messaging;

namespace PlayClientAppTest
{
    [TestClass]
    public class PlayServiceAdapterTest
    {
        #region [Success Scenarios Test]
        [TestMethod]
        public void LetsPlayTest()
        {
            Assert.AreEqual<string>(new PlayServiceAdapter().LetsPlay(GameNameConstant.Football), GameNameConstant.LetsPlay + GameNameConstant.Football);
        }

        [TestMethod]
        public async Task LetsPlayAsyncTestAsync()
        {
            Assert.AreEqual<string>(await new PlayServiceAdapter().LetsPlayAsync(GameNameConstant.Football), GameNameConstant.LetsPlay + GameNameConstant.Football);
        }
        #endregion [Successful Scenarios Test]

        #region [Unsuccessful Scenarios Test]

        #endregion [Unsuccessful Scenarios Test]
    }
}
