﻿namespace PlayClientApp.Messaging
{
    public static class GameNameConstant
    {
        #region [TypeOfGame]
        public const string Football = "Football";
        public const string Cricket = "Cricket";
        public const string Tenis = "Tenis";
        public const string Baseball = "Baseball";
        #endregion [TypeOfGame]

        public const string LetsPlay = "Lets Play ";
    }
}
