﻿using System;
using System.ServiceModel;
using System.Threading.Tasks;

namespace PlayClientApp.Adapters
{
    public class PlayServiceAdapter
    {
        /// <summary>
        /// Lets Play Operation using Play Service
        /// </summary>
        /// <param name="nameOfGame"></param>
        /// <returns></returns>
        public string LetsPlay(string nameOfGame)
        {
            string result = String.Empty;
            try
            {
                using (var s = new PlayOperationService.PlayServiceClient())
                {
                    result = s.PlayGameOperation(nameOfGame);
                    s.Close();
                }
            }
            catch(FaultException<PlayOperationService.PlayServiceException>ex)
            {
                Console.WriteLine("Play Service Error- {0}", ex.Message);
                throw;
            }

            catch(CommunicationException ex)
            {
                Console.WriteLine("Play Service Communication Error- Please check service is up or not !!!" + ex.Message);
                throw;
            }
            catch(Exception ex)
            {
                Console.WriteLine("Play Service Adapter Error-" + ex.Message);
                throw;
            }

            return result;
        }

        /// <summary>
        /// Asynchronous Lets Play Operation using Play Service
        /// </summary>
        /// <param name="nameOfGame"></param>
        /// <returns></returns>
        public async Task<string> LetsPlayAsync(string nameOfGame)
        {
            string result = String.Empty;
            try
            {
                using (var s = new PlayOperationService.PlayServiceClient())
                {
                    result = await s.PlayGameOperationAsync(nameOfGame);
                    s.Close();
                    Console.ReadKey();
                }
            }
            catch (FaultException<PlayOperationService.PlayServiceException> ex)
            {
                Console.WriteLine("Play Service Error- {0}", ex.Message);
                throw;
            }
           
            catch (CommunicationException ex)
            {
                Console.WriteLine("Play Service Communication Error- Please check service is up or not !!!" + ex.Message);
                throw;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Play Service Adapter Error-" + ex.Message);
                throw;
            }

            return result;
        }
    }
}
