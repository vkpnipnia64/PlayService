﻿using PlayClientApp.Adapters;
using PlayClientApp.Messaging;
using System;
namespace PlayClientApp
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine(new PlayServiceAdapter().LetsPlay(GameNameConstant.Football));
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.WriteLine("Press any Key to exit");
            Console.ReadKey();
        }
    }
}
