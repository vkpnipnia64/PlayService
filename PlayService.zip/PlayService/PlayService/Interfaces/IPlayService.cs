﻿using PlayService.Messaging;
using System.ServiceModel;

namespace PlayService
{
    [ServiceContract(Namespace ="CoreLaneTechnolgy.PlayService")]
    public interface IPlayService
    {
        [OperationContract(Name ="PlayGameOperation")]
        [FaultContract(typeof(PlayServiceException))]
        string PlayOperation(string nameOfGame);
    }
}
