﻿using System;
using System.ServiceModel;

namespace PlayService
{
    class Program
    {
        static void Main(string[] args)
        {
            using (ServiceHost s = new ServiceHost(typeof(PlayService)))
            {
                s.Open();
                Console.WriteLine("Service is up and running...\n");
                Console.WriteLine("Press any key to close the service...");
                Console.ReadKey();
            }
        }
    }
}
