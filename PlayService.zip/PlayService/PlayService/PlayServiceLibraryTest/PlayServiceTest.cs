using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PlayService.Messaging;
using System.ServiceModel;

namespace PlayServiceLibraryTest
{
    [TestClass]
    public class PlayServiceTest
    {
        [TestMethod]
        public void PlayOperationTest()
        {
            //Football
            var inputString = GameNameConstant.Football;
            var outputString = new PlayService.PlayService().PlayOperation(inputString);
            Assert.AreEqual<string>(outputString, GameNameConstant.LetsPlay + GameNameConstant.Football);

            //Baseball
            var inputString2 = GameNameConstant.Baseball;
            var outputString2 = new PlayService.PlayService().PlayOperation(inputString2);
            Assert.AreEqual<string>(outputString2, GameNameConstant.LetsPlay + GameNameConstant.Baseball);

            //Cricket
            var inputString3 = GameNameConstant.Cricket;
            var outputString3 = new PlayService.PlayService().PlayOperation(inputString3);
            Assert.AreEqual<string>(outputString3, GameNameConstant.LetsPlay + GameNameConstant.Cricket);

            //Tenis
            var inputString4 = GameNameConstant.Tenis;
            var outputString4 = new PlayService.PlayService().PlayOperation(inputString4);
            Assert.AreEqual<string>(outputString4, GameNameConstant.LetsPlay + GameNameConstant.Tenis);

            //Fault Exception Simulation
            try
            {
                var inputString5 = "Random Game";
                var outputString5 = new PlayService.PlayService().PlayOperation(inputString5);
            }
            catch (FaultException<PlayServiceException> ex)
            {
                Assert.IsNotNull(ex.Message);
            }
        }

        [TestMethod]
        public void PlayOperationParameterTest()
        {
            try
            {
                new PlayService.PlayService().PlayOperation(String.Empty);
            }
            catch(FaultException<PlayServiceException>ex)
            {
                Assert.IsNotNull(ex.Message);
            }
        }
    }
}
