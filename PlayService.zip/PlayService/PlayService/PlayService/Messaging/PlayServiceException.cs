﻿using System;
using System.Runtime.Serialization;

namespace PlayService.Messaging
{
    [DataContract(Namespace = "CoreLaneTechnolgy.PlayService.Messaging")]
    public class PlayServiceException
    {
        [DataMember]
        public string ErrorMessage { get; set; }

        [DataMember]
        public Exception InnerException { get; set; }
    }
}
