﻿using PlayService.Messaging;
using System;
using System.Collections.Generic;
using System.ServiceModel;

namespace PlayService
{
    /// <summary>
    /// PlayService Implementation Class
    /// </summary>
    public class PlayService : IPlayService
    {
        #region [Contract Exposed Public Methods]
        /// <summary>
        /// PlayOperation- Return Output string based on input GameName
        /// </summary>
        /// <param name="nameOfGame"></param>
        /// <returns>output string with Game Name (Format - Lets Play Football)</returns>
        public string PlayOperation(string nameOfGame)
        {
            try
            {
                //let the client know if input is empty or null
                if (String.IsNullOrEmpty(nameOfGame))
                    throw new FaultException<PlayServiceException>(new PlayServiceException { ErrorMessage = "Parameter Error- Please pass a valid gameName" });

                return GetPlayOperationOutput(nameOfGame);
            }
            catch (Exception ex)
            {
                throw new FaultException<PlayServiceException>(new PlayServiceException { ErrorMessage = "Play Operation Error-", InnerException = ex });
            }
        }
        #endregion [Contract Exposed Public Methods]

        #region [Helper Private Methods]
        private string GetPlayOperationOutput(string nameOfGame)
        {
            return new Dictionary<string, Func<string>>
            {
                { GameNameConstant.Football,    ()=> GameNameConstant.LetsPlay +  GameNameConstant.Football},
                { GameNameConstant.Cricket ,    ()=> GameNameConstant.LetsPlay + GameNameConstant.Cricket },
                { GameNameConstant.Tenis ,      ()=> GameNameConstant.LetsPlay + GameNameConstant.Tenis},
                { GameNameConstant.Baseball,    ()=> GameNameConstant.LetsPlay + GameNameConstant.Baseball},

            }[nameOfGame]();
        }
        #endregion [Helper Private Methods]
    }
}
