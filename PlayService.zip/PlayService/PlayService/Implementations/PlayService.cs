﻿using PlayService.Messaging;
using System;
using System.Collections.Generic;
using System.ServiceModel;

namespace PlayService
{
    public class PlayService : IPlayService
    {
        #region [Contract Exposed Public Methods]
        public string PlayOperation(string nameOfGame)
        {
            try
            {
                if (String.IsNullOrEmpty(nameOfGame))
                    throw new FaultException<PlayServiceException>(new PlayServiceException { ErrorMessage = "Parameter Error- Please pass a valid gameName" });

                return GetPlayOperationOutput(nameOfGame);
            }
            catch (Exception ex)
            {
                throw new FaultException<PlayServiceException>(new PlayServiceException { ErrorMessage = "Play Operation Error-", InnerException = ex });
            }
        }
        #endregion [Contract Exposed Public Methods]

        #region [Helper Private Methods]
        private string GetPlayOperationOutput(string nameOfGame)
        {
            return new Dictionary<string, Func<string>>
            {
                { GameNameConstant.Football,    ()=> GameNameConstant.LetsPlay +  GameNameConstant.Football},
                { GameNameConstant.Cricket ,    ()=> GameNameConstant.LetsPlay + GameNameConstant.Cricket },
                { GameNameConstant.Tenis ,      ()=> GameNameConstant.LetsPlay + GameNameConstant.Tenis},
                { GameNameConstant.Baseball,    ()=> GameNameConstant.LetsPlay + GameNameConstant.Baseball},

            }[nameOfGame]();
        }
        #endregion [Helper Private Methods]

    }
}
